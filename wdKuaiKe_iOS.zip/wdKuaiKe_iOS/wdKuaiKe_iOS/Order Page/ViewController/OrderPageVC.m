//
//  OrderPageVC.m
//  wdKuaiKe_iOS
//
//  Created by Skyer God on 16/8/4.
//  Copyright © 2016年 weiDianKuaiKe. All rights reserved.
//

#import "OrderPageVC.h"

#import "TwoLineLabelButton.h"

@interface OrderPageVC ()<UITextFieldDelegate>
@property (nonatomic, strong) UIView *navigationView;

@property (nonatomic, strong) TwoLineLabelButton *selectButton;//用来记录区分点击button
@end

@implementation OrderPageVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBar.hidden = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self setUpNavigationView];
    
    [self setUpLabelAndOrderTime];
    
    [self setUpOrderTimeView];
}
#pragma mark -- ／／ 设置自定义navigationBar
- (void)setUpNavigationView{
        UIView *statusBarView = [[UIView alloc] init];
    statusBarView.backgroundColor = [UIColor blackColor];
    [self.view addSubview:statusBarView];
    statusBarView.sd_layout.leftSpaceToView(self.view, 0).topEqualToView(self.view).rightEqualToView(self.view).heightIs(20);
    
    _navigationView = [[UIView alloc] init];

    
    [self.view addSubview:_navigationView];
    _navigationView.sd_layout.leftEqualToView(self.view).topSpaceToView(statusBarView, 0).heightIs(44).rightEqualToView(self.view);
    
    UIButton *leftBarItem = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftBarItem setImage:[UIImage imageNamed:@"返回"] forState:UIControlStateNormal];
    [_navigationView addSubview:leftBarItem];
    leftBarItem.sd_layout.leftSpaceToView(_navigationView, 10).topSpaceToView(_navigationView, 10).widthIs(26).heightIs(21);
    
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = @"预约";
    titleLabel.font = [UIFont systemFontOfSize:20.0];
    titleLabel.textColor = RGB(222,123,38);
    
    [_navigationView addSubview:titleLabel];
    titleLabel.sd_layout.topSpaceToView(_navigationView, 10).bottomSpaceToView(_navigationView, 13).centerXEqualToView(_navigationView).centerYEqualToView(_navigationView).widthIs([[CalculateStringTool shareManager] getStringWidthWithString:titleLabel.text fontSize:titleLabel.font]);
    
    UIView *separaLine = [[UIView alloc] init];
    separaLine.backgroundColor = RGB(222,123,38);
    [_navigationView addSubview:separaLine];
    
    separaLine.sd_layout.topEqualToView(_navigationView).bottomEqualToView(_navigationView).heightIs(3).rightEqualToView(_navigationView);
    
    
    
}
#pragma mark -- 设置跑马灯label 喇叭 日历
- (void)setUpLabelAndOrderTime{
    
    UIImageView *hornImageV = [[UIImageView alloc] init];
    [hornImageV setImage:[UIImage imageNamed:@"通知"]];
    [self.view addSubview:hornImageV];
    hornImageV.sd_layout.leftSpaceToView(self.view, kWidth(11)).topSpaceToView(_navigationView, kHeight(23)).widthIs(kWidth(21)).heightIs(kHeight(20));
    
    //创建跑马灯label
    UILabel *hornLabel = [[UILabel alloc] init];
    hornLabel.text = @"吧啦吧啦吧啦吧啦啦吧啦吧啦啦吧啦吧啦啦不啦一大堆";
    hornLabel.font = [UIFont systemFontOfSize:14.0];
    hornLabel.backgroundColor = RGBA(222,123,38, 0.5019607843137255);
    [self.view addSubview:hornLabel];
    hornLabel.sd_layout.leftSpaceToView(hornImageV, kWidth(5)).topSpaceToView(_navigationView, kHeight(21)).rightSpaceToView(self.view, kWidth(20)).heightIs(kHeight(21));
    

    //创建三个时间button
    NSArray *arrTitlesFirst = @[@"今天", @"明天", @"后天"];
    NSArray *arrTitlesSecond = @[@"07-18 周一", @"07-19 周二", @"07-18 周三"];
    for (NSInteger i = 0; i < 3; i++) {
        
        TwoLineLabelButton *today = [TwoLineLabelButton buttonWithType:UIButtonTypeCustom];
        [self.view addSubview:today];
        
        today.firstLabel.text = [arrTitlesFirst objectAtIndex:i];
        today.secondLabel.text = [arrTitlesSecond objectAtIndex:i];
        CGFloat height = [[CalculateStringTool shareManager] getStringWidthWithString:today.secondLabel.text fontSize:today.secondLabel.font];
        today.sd_layout.leftSpaceToView(self.view, kWidth(21) + (height + kWidth(39))* i ).topSpaceToView(hornLabel, kHeight(20)).heightIs(kHeight(29)).widthIs(kWidth(height));
        today.heightFirst = 15.0;
        today.line_Space = 5.0;
        
        [today addTarget:self action:@selector(todayAction:) forControlEvents:UIControlEventTouchUpInside];
        today.tag = 4000 + i;
        

        if (today.tag == 4000) {
            today.selected = YES;
            _selectButton = today;
            today.firstLabel.textColor = RGB(234,128,16);
        } else {
            today.firstLabel.textColor = RGB(133,133,133);
        }

        today.secondLabel.textColor = today.firstLabel.textColor;
        
     
    }

    //日历button
    UIButton *calendarBT = [UIButton buttonWithType:UIButtonTypeCustom];
    [calendarBT setImage:[UIImage imageNamed:@"日历"] forState:UIControlStateNormal];
    [self.view addSubview:calendarBT];
    calendarBT.sd_layout.topSpaceToView(hornLabel, kHeight(22)).rightSpaceToView(self.view, kWidth(37)).widthIs(kWidth(20)).heightIs(kHeight(18));
    //分割线
    UIView *secondSeparaLine = [[UIView alloc] init];
    secondSeparaLine.backgroundColor = RGBA(216,216,216, 0.8);
    [self.view addSubview:secondSeparaLine];
    
    secondSeparaLine.sd_layout.leftEqualToView(self.view).topSpaceToView([self.view viewWithTag:4000], kHeight(20)).rightEqualToView(self.view).heightIs(kHeight(3));
    
#pragma mark ----- 告一段落－－－－😭－－－－－
    
#pragma mark ----- 创建预订时间开始后的分栏视图------我也不想这么一点点铺图----血崩----
    //预订时间button
    UILabel *orderTimeLabel = [[UILabel alloc] init];
    orderTimeLabel.text = @"预订时间:";
    orderTimeLabel.font = [UIFont systemFontOfSize:12.0];
    orderTimeLabel.textColor = RGB(133,133,133);
    [self.view addSubview:orderTimeLabel];
    
    orderTimeLabel.sd_layout.leftSpaceToView(self.view, kWidth(11)).topSpaceToView(secondSeparaLine, kHeight(18)).widthIs(kWidth([[CalculateStringTool shareManager] getStringWidthWithString:orderTimeLabel.text fontSize:orderTimeLabel.font])).heightIs(kHeight(12));
    
    //显示选中后的button的时间
    UILabel *timeSelectLabel = [[UILabel alloc] init];
    timeSelectLabel.textColor = RGB(234,128,16);
    timeSelectLabel.text = @"10:30";
    timeSelectLabel.font = [UIFont systemFontOfSize:12.0];
    [self.view addSubview:timeSelectLabel];
    
    timeSelectLabel.sd_layout.leftSpaceToView(orderTimeLabel, kWidth(11)).topSpaceToView(secondSeparaLine, kHeight(19)).widthIs(kWidth([[CalculateStringTool shareManager] getStringWidthWithString:timeSelectLabel.text fontSize:timeSelectLabel.font])).heightIs(kHeight(10));
    
    // 全天的button
    UILabel *wholeDay = [[UILabel alloc] init];
    wholeDay.textColor = RGB(234,128,16);
    wholeDay.text = @"全天";
    wholeDay.font = [UIFont systemFontOfSize:12.0];
    [self.view addSubview:wholeDay];
    
    wholeDay.sd_layout.leftSpaceToView(self.view, kWidth(22)).topSpaceToView(orderTimeLabel, kHeight(25)).widthIs(kWidth(24)).heightIs(kHeight(12));
    
    //创建8个时间选择标签 tag值5000起步
    for (NSInteger i = 0; i < 8; i++) {
        
        NSInteger row = i / 4;
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setTitleColor: RGB(234,128,16) forState:UIControlStateNormal];
        [button setBackgroundColor:RGB(225,225,225)];
        [button setTitle:@"10:30" forState:UIControlStateNormal];
        [button.titleLabel setFont: [UIFont systemFontOfSize:12.0]];
        [self.view addSubview:button];
        button.tag = 5000 + i;
        
        [button addTarget:self action:@selector(timeSelectButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        

        
        button.sd_layout.leftSpaceToView(self.view, kWidth(21 + (52 + 45) * (i > 3 ? i % 4 : i))).topSpaceToView(wholeDay, kHeight(11) + (kHeight(18 + 17)) * row).widthIs(kWidth(45)).heightIs(kHeight(17));
        
        button.layer.cornerRadius = button.size.height / 2;
        button.clipsToBounds = YES;
    }
    //设置坐台要求标签
    UILabel *deskOrder = [[UILabel alloc] init];
    deskOrder.text = @"桌台要求";
    deskOrder.textColor = RGB(234,128,16);
    deskOrder.font = [UIFont systemFontOfSize:12.0];
    [self.view addSubview:deskOrder];
    
    deskOrder.sd_layout.leftEqualToView(wholeDay).topSpaceToView(wholeDay, kHeight(77)).widthIs(kWidth(48)).heightIs(kHeight(12));
    

    
    //设置桌台类型选择segment
    UISegmentedControl *deskCatagory = [[UISegmentedControl alloc]initWithItems:@[@"散座", @"包厢", @"卡座"]];
    deskCatagory.backgroundColor = [UIColor whiteColor];
    deskCatagory.tintColor = RGB(234,128,16);
    NSInteger static num = 0;
    deskCatagory.selectedSegmentIndex = num;
    [deskCatagory addTarget:self action:@selector(segAction:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:deskCatagory];
    
    deskCatagory.sd_layout.leftEqualToView(deskOrder).topSpaceToView(deskOrder, kHeight(19)).rightSpaceToView(self.view, kWidth(20)).heightIs(kWidth(27));

    deskCatagory.layer.borderColor = RGB(234,128,16).CGColor;
    deskCatagory.layer.borderWidth = 1;
    
//    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], NSForegroundColorAttributeName,[UIFont systemFontOfSize:14],NSFontAttributeName,nil];
    
//    [deskCatagory setTitleTextAttributes:dic forState:UIControlStateNormal];
    
    deskCatagory.layer.cornerRadius = deskCatagory.size.height / 2;
    deskCatagory.layer.masksToBounds = YES;
    
    //设置特殊需求;
    
    UILabel *specialOrder = [[UILabel alloc] init];
    specialOrder.text = @"特殊需求：无";
    specialOrder.textColor = RGB(234,128,16);
    specialOrder.font = deskOrder.font;
    [self.view addSubview:specialOrder];
    
    specialOrder.sd_layout.leftEqualToView(deskOrder).topSpaceToView(deskCatagory, kHeight(15)).widthIs([[CalculateStringTool shareManager] getStringWidthWithString:specialOrder.text fontSize:specialOrder.font]).heightIs(kHeight(12));
    
    
    //设置用餐人数
    UILabel *peopleNum = [[UILabel alloc] init];
    peopleNum.text = @"用餐人数";
    peopleNum.textColor = specialOrder.textColor;
    peopleNum.font = specialOrder.font;
    [self.view addSubview:peopleNum];
    
    
    peopleNum.sd_layout.leftEqualToView(specialOrder).topSpaceToView(specialOrder, kHeight(33)).widthIs(kWidth(48)).heightIs(kHeight(12));
    
    UIView *peopleSelect = [[UIView alloc] init];
    peopleSelect.layer.borderWidth = 1;
    peopleSelect.layer.borderColor = RGB(234,128,16).CGColor;
    [self.view addSubview:peopleSelect];
    
    peopleSelect.sd_layout.leftSpaceToView(peopleNum, kWidth(16)).topSpaceToView(specialOrder, kHeight(21)).widthIs(kWidth(93)).heightIs(kHeight(32));
    
//    设置加号
    UIButton *jiaButton = [UIButton buttonWithType:UIButtonTypeCustom];
    jiaButton.layer.borderColor = RGB(234,128,16).CGColor;
    jiaButton.layer.borderWidth = 0.5;
    [jiaButton setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
    [jiaButton addTarget:self action:@selector(jiaButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [peopleSelect addSubview:jiaButton];
    jiaButton.sd_layout.leftEqualToView(peopleSelect).topEqualToView(peopleSelect).widthRatioToView(peopleSelect, 1.0 / 3).bottomEqualToView(peopleSelect);
    
    //设置减号
    UIButton *jianButton = [UIButton buttonWithType:UIButtonTypeCustom];
    jianButton.layer.borderColor = RGB(234,128,16).CGColor;
    jianButton.layer.borderWidth = 0.5;
    [jianButton setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
    [jianButton addTarget:self action:@selector(jiaButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [peopleSelect addSubview:jianButton];
    jianButton.sd_layout.topEqualToView(peopleSelect).widthRatioToView(peopleSelect, 1.0 / 3).bottomEqualToView(peopleSelect).rightEqualToView(peopleSelect);
    
    UITextField *textField = [[UITextField alloc] init];
    textField.placeholder = @"5";
    textField.text = @"5";
    textField.textColor = RGB(234,128,16);
    textField.textAlignment = NSTextAlignmentCenter;
    [textField addTarget:self action:@selector(textFieldDidBeginEditing:) forControlEvents:UIControlEventTouchUpInside];
    
    textField.autocorrectionType = UITextAutocorrectionTypeNo;
    textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    textField.returnKeyType = UIReturnKeyDone;
    
    textField.delegate = self;

    [peopleSelect addSubview:textField];
    
    textField.sd_layout.leftSpaceToView(jiaButton, 0).topEqualToView(peopleSelect).rightSpaceToView(jianButton, 0).bottomEqualToView(peopleSelect);
    
    
    
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
- (BOOL)isPartialStringValid: (NSString **) partialStringPtr
        proposedSelectedRange: (NSRangePointer) proposedSelRangePtr
               originalString: (NSString *) origString
        originalSelectedRange: (NSRange) origSelRange
             errorDescription: (NSString **) error
{
    NSCharacterSet *nonDigits;
    NSRange newStuff;
    NSString *newStuffString;
    
    nonDigits = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
    newStuff = NSMakeRange(origSelRange.location,
                           proposedSelRangePtr->location
                           - origSelRange.location);
    newStuffString = [*partialStringPtr substringWithRange: newStuff];
    
    if ([newStuffString rangeOfCharacterFromSet: nonDigits
                                        options: NSLiteralSearch].location != NSNotFound) {
        *error = @"不是数字";
        return (NO);
    } else {
        *error = nil;
        return (YES);
    }
    
}

- (void)jiaButtonAction:(UIButton *)sender{
    
}

- (void)segAction:(UISegmentedControl *)sender{
    
}
- (void)timeSelectButtonClick:(UIButton *)sender{
    
    NSLog(@"%ld, %@", sender.tag, sender.titleLabel.text);
}

- (void)todayAction:(TwoLineLabelButton *)sender{
    
    
    if (sender == _selectButton) {
        

    } else {


            sender.firstLabel.textColor = RGB(234,128,16);
        
            sender.secondLabel.textColor = sender.firstLabel.textColor;
        
        _selectButton.firstLabel.textColor = RGB(133,133,133);
        
        _selectButton.secondLabel.textColor = _selectButton.firstLabel.textColor;
        
    }
    _selectButton = sender;
    NSLog(@"%ld", (long)sender.tag);
    
}
#pragma mark ----- 告一段落－－－－😭－－－－－

#pragma mark ----- 创建预订时间开始后的分栏视图------我也不想这么一点点铺图----血崩----


- (void)setUpOrderTimeView {

    
}


- (void)didReceiveMemoryWarning {
    
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.

    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
