//
//  AppDelegate.m
//  wdKuaiKe_iOS
//
//  Created by Skyer God on 16/8/3.
//  Copyright © 2016年 weiDianKuaiKe. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()<UITabBarControllerDelegate, UITabBarDelegate>

@property (nonatomic, retain) UITabBarController *tabController;

//设置中间middleItem
@property (nonatomic, retain) UITabBarItem *middleItem;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.

    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    
    self.window.backgroundColor = [UIColor whiteColor];
    
    [self.window makeKeyAndVisible];
    
    //初始化tabbarcontroller
    [self initWithTabBarController];
    
    //baidu---
    NSLog(@"%@",[[NSBundle mainBundle] bundleIdentifier]);
    return YES;
}
- (void)initWithTabBarController{
    //初始化tablebar个数
    NSArray *arrTitle         = @[@"首页", @"预约", @"", @"服务", @"我的"];
    
    //vc个数
    NSArray *arrClass         = @[@"HomePageVC", @"OrderPageVC", @"MiddlePageVC" ,@"ServicePageVC", @"MinePageVC"];
    
    //初始化tablebar图标
    NSArray *arrBarIcon       = @[@"home.png", @"order.png", @"add.png", @"service.png", @"own.png"];
    
    //创建tabbar数组
    NSMutableArray *arrNC     = [NSMutableArray array];
    
    for (NSString *classStr in arrClass) {
        
        Class className = NSClassFromString(classStr);
        
        if (className) {
            
            static NSInteger i = 0;
            
            UIViewController *viewController = [[[className class] alloc]init];
            
            UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:viewController];
            
            navigationController.title = [arrTitle objectAtIndex:i];
            
            [arrNC addObject:navigationController];
            
            if (i != 2) {
                
                [navigationController.tabBarItem setImage:[UIImage imageNamed:[arrBarIcon objectAtIndex:i]]];
                
                
            }
            
            i++;
            
            
        }
    }
    
    self.tabController = [[UITabBarController alloc] init];
    
    self.tabController.tabBar.barTintColor = [UIColor lightTextColor];
    
    [self.tabController.tabBar setTintColor:RGB(253, 117, 119)];
    
    self.tabController.viewControllers = [arrNC copy];
    
    self.tabController.delegate = self;
    
    //覆盖中间tabbar
    [self setMiddleButton];
    
    self.window.rootViewController = self.tabController;
}
- (void)setMiddleButton{
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    button.frame = CGRectMake(self.window.frame.size.width / 5 * 2 + kWidth(10), self.window.frame.size.height - kHeight(49 - 5), self.window.frame.size.width / 5 - kWidth(10) * 2, kHeight(49 - 5 * 2));
    
    [button imageRectForContentRect:button.frame];
    
    [button setBackgroundImage:[UIImage imageNamed:@"add.png"] forState:UIControlStateNormal];
    
    button.layer.cornerRadius = button.frame.size.height / 8;
    
    button.clipsToBounds = YES;
    button.tag = 2000;
    [button addTarget:self action:@selector(midButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    self.tabController.delegate = self;
    
    [self.tabController.view addSubview:button];
    
    
    
}
- (void)action{
    NSLog(@"sdf");
}
- (void)midButtonAction:(UIButton *)button {
    
//    addVC *vc = [[addVC alloc] init];
//    
//    [self.tabController presentViewController:vc animated:YES completion:nil];
    
}
//tabBarController － delegate方法
- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController{
    if (viewController == [tabBarController.viewControllers objectAtIndex:2]) {
        return NO;
        
    } else return YES;
}

- (void)tabBar:(UITabBar *)tabBar willEndCustomizingItems:(NSArray<UITabBarItem *> *)items changed:(BOOL)changed{
    
}
- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController{
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"homePageClick" object:nil];
    if (tabBarController.selectedIndex == 1) {
        
//        self.tabController.tabBar.hidden = YES;
//        [self.tabController.view viewWithTag:2000].hidden = YES;
        
        
        
    }
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
