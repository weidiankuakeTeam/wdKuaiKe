//
//  EvaluateDetailListCell.m
//  wdKuaiKe_iOS
//
//  Created by Skyer God on 16/8/8.
//  Copyright © 2016年 weiDianKuaiKe. All rights reserved.
//

#import "EvaluateDetailListCell.h"

@implementation EvaluateDetailListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(void)setFrame:(CGRect)frame{
    frame.origin.y += kHeight(1);
    frame.size.height -= kHeight(1);
    [super setFrame:frame];
    
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self create];
    }
    return self;
}
- (void)create{
    
    self.userButton= [UIButton buttonWithType:UIButtonTypeCustom];
    [self.userButton setImage:[UIImage imageNamed:@"tian"] forState:UIControlStateNormal];
    [self.userButton setTitle:@"微点筷客" forState:UIControlStateNormal];
    [self.userButton setTitleColor:RGB(48, 48, 48) forState:UIControlStateNormal];

    [self.userButton.titleLabel setFont:[UIFont systemFontOfSize:9.0]];
    
    [self.contentView addSubview:_userButton];
    
    self.timeLabel = [[UILabel alloc]init];
    self.timeLabel.text = @"2016-08-08";
    self.timeLabel.textColor = RGB(132, 132, 132);
    self.timeLabel.font = [UIFont systemFontOfSize:9.0];
    self.timeLabel.textAlignment = NSTextAlignmentRight;
    
    [self.contentView addSubview:self.timeLabel];
    
    
    self.detailLabel = [[UILabel alloc]init];
    self.detailLabel.text = @"菜品不错，味道鲜美很好吃，下次再来！菜品不错，味道鲜美菜品不错，味道鲜美很好吃，下次再来！菜品不错，味道鲜美菜品不错，味道鲜美很好吃，下次再来！菜品不错，味道鲜美菜品不错，味道鲜美很好吃，下次再来！菜品不错，味道鲜美";
    self.detailLabel.textColor = RGB(132,132,132);
    self.detailLabel.font = [UIFont systemFontOfSize:9.0];
    self.detailLabel.numberOfLines = 0;
    
    [self.contentView addSubview:self.detailLabel];
    
    
    
    
}
- (void)layoutSubviews{
    [super layoutSubviews];
    
    
    CGRect rect = [_userButton.titleLabel.text boundingRectWithSize:CGSizeMake(10000, _userButton.titleLabel.size.height) options:NSStringDrawingUsesLineFragmentOrigin attributes:[NSDictionary dictionaryWithObject:[UIFont systemFontOfSize:9.0] forKey:NSFontAttributeName] context:nil];

    self.userButton.sd_layout.leftSpaceToView(self.contentView, 19).topSpaceToView(self.contentView, 12).widthIs(28 + rect.size.width + 7).heightIs(28);
    
    [self.userButton setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, rect.size.width)];
    [self.userButton setTitleEdgeInsets:UIEdgeInsetsMake(5, 7, 13, 0)];
    
    self.userButton.imageView.layer.cornerRadius = self.userButton.imageView.frame.size.height / 2;
    
    self.userButton.imageView.clipsToBounds = YES;
    
    
    self.timeLabel.sd_layout.topSpaceToView(self.contentView, 18).rightSpaceToView(self.contentView, 14).widthIs([[CalculateStringTool shareManager] getStringWidthWithString:_timeLabel.text fontSize:_timeLabel.font]).heightIs(8);
    
    
    self.detailLabel.sd_layout.leftSpaceToView(self.contentView, 57).topSpaceToView(_userButton, 2).rightSpaceToView(self.contentView, 16).heightIs(41);
    
    
    
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
