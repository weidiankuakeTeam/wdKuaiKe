//
//  PhoneTableViewCell.m
//  wdKuaiKe_iOS
//
//  Created by Skyer God on 16/8/8.
//  Copyright © 2016年 weiDianKuaiKe. All rights reserved.
//

#import "PhoneTableViewCell.h"

@implementation PhoneTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(void)setFrame:(CGRect)frame{
    frame.origin.y += kHeight(14);
    frame.size.height -= kHeight(14);
    [super setFrame:frame];
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self create];
    }
    return self;
}
- (void)create{
    
    self.timeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.timeButton setImage:[UIImage imageNamed:@"时间-(1)"] forState:UIControlStateNormal];
    [self.timeButton setTitle:@"暂无" forState:UIControlStateNormal];
    self.timeButton.titleLabel.font = [UIFont systemFontOfSize:12.0];
    [self.timeButton setTitleColor:RGB(48,48,48) forState:UIControlStateNormal];
    [self.contentView addSubview:_timeButton];
    
    self.phoneButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.phoneButton setImage:[UIImage imageNamed:@"电话"] forState:UIControlStateNormal];
    [self.phoneButton setTitle:@"0592-00000000" forState:UIControlStateNormal];
    self.phoneButton.titleLabel.font = _timeButton.titleLabel.font;
    [self.phoneButton setTitleColor:RGB(48,48,48) forState:UIControlStateNormal];
    [self.contentView addSubview:_phoneButton];
    
    
    
    
}

- (void)layoutSubviews{
    [super layoutSubviews];
    
//    self.timeButton.sd_layout.leftSpaceToView(self, -150).topSpaceToView(self, 14).heightIs(19.0).widthIs(52.0);
    self.timeButton.frame = CGRectMake(23, 14, 52, 19);
    self.phoneButton.sd_layout.leftSpaceToView(_timeButton,139).topEqualToView(_timeButton).rightEqualToView(self.contentView).bottomEqualToView(_timeButton);
    
    [self.timeButton setTitleEdgeInsets:UIEdgeInsetsMake(0, 9, 0, 0)];
    [self.phoneButton setTitleEdgeInsets:UIEdgeInsetsMake(0, 9, 0, 0)];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
