//
//  MerchantOptionBTCell.m
//  wdKuaiKe_iOS
//
//  Created by Skyer God on 16/8/5.
//  Copyright © 2016年 weiDianKuaiKe. All rights reserved.
//

#define Start_X 24.0
#define Row_Space 34.0

#define Start_Y  10.0
#define Bottom_Y 19.0


#define Button_Width (self.bounds.size.width - (34 * 3) - (24 * 2)) / 4


#import "MerchantOptionBTCell.h"
#import "BaseButton.h"

@interface MerchantOptionBTCell ()
    
@property (nonatomic, retain) NSArray *arrTitles;


@end

@implementation MerchantOptionBTCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createFourButton];
    }
    return self;
}
- (void)createFourButton{
    
    _arrTitles = @[@"食堂点餐", @"预定", @"排队", @"代金劵"];
    NSArray *arrImages = @[@"点餐", @"取号排队", @"团队", @"代金券-(1)"];
    
    for (NSInteger i = 0; i < _arrTitles.count; i++) {
        
        BaseButton *button = [BaseButton buttonWithType:UIButtonTypeCustom];
        
        [button setImage:[UIImage imageNamed:[arrImages objectAtIndex:i]] forState:UIControlStateNormal];
        
        [button setTitle:[_arrTitles objectAtIndex:i] forState:UIControlStateNormal];
        
        [button setTitleColor:RGB(64,64,64) forState:UIControlStateNormal];
        
        button.titleLabel.font = [UIFont systemFontOfSize:12.0];
        
        button.tag = 4000 + i;
        
        [self.contentView addSubview:button];
        button.Image_Y = 8;
        button.Title_Space = 8;
        
        
       

    }
}
-(void)layoutSubviews{
    [super layoutSubviews];
    
    for (NSInteger i = 0; i < _arrTitles.count; i++) {
        
        BaseButton *button = [self viewWithTag:i + 4000];
        
        button.frame = CGRectMake(Start_X + (Button_Width  + Row_Space )* i , Start_Y, Button_Width, self.frame.size.height - Start_Y * 2);
        
        [button setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 30, 0)];
        
        
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
