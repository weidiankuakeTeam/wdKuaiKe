//
//  LocationTableViewCell.m
//  wdKuaiKe_iOS
//
//  Created by Skyer God on 16/8/8.
//  Copyright © 2016年 weiDianKuaiKe. All rights reserved.
//

#import "LocationTableViewCell.h"

@implementation LocationTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(void)setFrame:(CGRect)frame{
    frame.origin.y += kHeight(1);
    frame.size.height -= kHeight(1);
    [super setFrame:frame];
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self create];
    }
    return self;
    
}

- (void)create{
    
    self.locationBT = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.locationBT setImage:[UIImage imageNamed:@"地址"] forState:UIControlStateNormal];
    [self.locationBT setTitle:@"厦门市思明区软件园二期观日路XXXX" forState:UIControlStateNormal];
    [self.locationBT setTitleColor:RGB(48,48,48) forState:UIControlStateNormal];
    [self.locationBT.titleLabel setFont:[UIFont systemFontOfSize:12.0]];
    [self.locationBT setTitleEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
    [self.locationBT.titleLabel setTextAlignment:NSTextAlignmentLeft];
    [self.contentView addSubview:_locationBT];
    
    self.arrowBT = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.arrowBT setImage:[UIImage imageNamed:@"形状-1-拷贝"] forState:UIControlStateNormal];
    [self.arrowBT setTitle:@"到这去" forState:UIControlStateNormal];
    [self.arrowBT setTitleColor:RGB(132, 132, 132) forState:UIControlStateNormal];
    [self.arrowBT.titleLabel setFont:[UIFont systemFontOfSize:12.0]];
    [self.contentView addSubview:_arrowBT];
    

   
    
    
}

-(void)layoutSubviews{
    [super layoutSubviews];
    
    CGRect rect = [_locationBT.titleLabel.text boundingRectWithSize:CGSizeMake(10000, _locationBT.titleLabel.size.height) options:NSStringDrawingUsesLineFragmentOrigin attributes:[NSDictionary dictionaryWithObject:[UIFont systemFontOfSize:_locationBT.titleLabel.font.pointSize] forKey:NSFontAttributeName] context:nil];
    
    self.locationBT.sd_layout.leftSpaceToView(self.contentView, 24).topSpaceToView(self.contentView, 11).widthIs(rect.size.width + 26).heightIs(21);
    
    self.arrowBT.sd_layout.topSpaceToView(self.contentView, 14).rightSpaceToView(self.contentView, 15).heightIs(13).widthIs(47);
    [self.arrowBT setImageEdgeInsets:UIEdgeInsetsMake(0, 36 + 3, 0, 0)];
    [self.arrowBT setTitleEdgeInsets:UIEdgeInsetsMake(0, -(36 - 8 - 3), 0, 0)];
    
    
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
