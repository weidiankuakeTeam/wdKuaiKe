//
//  LeftRightButton.h
//  WDKKtest
//
//  Created by Skyer God on 16/7/26.
//  Copyright © 2016年 weiDianKuaiKe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftRightButton : UIButton

@end
