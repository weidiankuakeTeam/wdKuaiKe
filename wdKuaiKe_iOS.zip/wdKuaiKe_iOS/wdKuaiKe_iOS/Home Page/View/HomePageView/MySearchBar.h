//
//  MySearchBar.h
//  WDKKtest
//
//  Created by Skyer God on 16/7/28.
//  Copyright © 2016年 weiDianKuaiKe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MySearchBar : UISearchBar

- (void)layoutSubviews;

@end
