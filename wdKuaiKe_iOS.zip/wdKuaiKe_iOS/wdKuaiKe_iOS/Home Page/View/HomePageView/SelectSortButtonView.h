//
//  SelectSortButtonCell.h
//  WDKKtest
//
//  Created by Skyer God on 16/7/21.
//  Copyright © 2016年 weiDianKuaiKe. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "LeftRightButton.h"
@interface SelectSortButtonView : UIView
@property (nonatomic, retain) LeftRightButton *allButton;
@property (nonatomic, retain) LeftRightButton *nearbyButton;
@property (nonatomic, retain) LeftRightButton *autoSortButton;
@property (nonatomic, retain) LeftRightButton *filterButton;


@end
