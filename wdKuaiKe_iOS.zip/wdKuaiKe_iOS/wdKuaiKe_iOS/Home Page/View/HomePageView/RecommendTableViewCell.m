//
//  RecommendTableViewCell.m
//  WDKKtest
//
//  Created by Skyer God on 16/7/21.
//  Copyright © 2016年 weiDianKuaiKe. All rights reserved.
//
#define Start_X 15.0f
#define Start_Y 15.0f
#define Row_Space 20.0f
#define ImageV_Width (self.frame.size.width - ((Start_X * 2) + Row_Space)) / 2
#import "RecommendTableViewCell.h"

@implementation RecommendTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    

    
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{

    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self) {
        [self createRecommendImageView];
    }
    return self;
}
- (void)createRecommendImageView{
    
    self.firstImageV = [[UIImageView alloc] init];
    
    self.firstImageV.backgroundColor = [UIColor yellowColor];
    
    [self.contentView addSubview:_firstImageV];
    
    self.secondImageV = [[UIImageView alloc] init];
    
    self.secondImageV.backgroundColor = [UIColor cyanColor];
    
    [self.contentView addSubview:_secondImageV];
    
    self.firstImageV.image = [UIImage imageNamed:@"first"];
    
    self.secondImageV.image = [UIImage imageNamed:@"second"];
}
- (void)layoutSubviews {
    [super layoutSubviews];
    
    self.firstImageV.frame = CGRectMake(Start_X, Start_Y, ImageV_Width, self.frame.size.height - Start_Y * 2);
    self.firstImageV.layer.cornerRadius = self.frame.size.height / 12;
    self.firstImageV.clipsToBounds = YES;
    
    self.secondImageV.frame = CGRectMake(_firstImageV.frame.origin.x + _firstImageV.frame.size.width + Row_Space, _firstImageV.frame.origin.y, _firstImageV.frame.size.width, _firstImageV.frame.size.height);
    
    self.secondImageV.layer.cornerRadius = _firstImageV.layer.cornerRadius;
    self.secondImageV.clipsToBounds = YES;
    
    
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
