//
//  SelectSortButtonCell.m
//  WDKKtest
//
//  Created by Skyer God on 16/7/21.
//  Copyright © 2016年 weiDianKuaiKe. All rights reserved.
//
#define Row_Space 0.1f

#define Button_Width (self.frame.size.width - (Row_Space * 3)) / 4
#import "SelectSortButtonView.h"

@interface SelectSortButtonView ()
@property (nonatomic, strong) UIButton *selectButton;
@property (nonatomic, retain) NSArray *arrButton;

@end
@implementation SelectSortButtonView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    
    if (self) {
        [self createSelectSortButton];
        self.layer.borderColor = [UIColor colorWithRed:0.7482 green:0.7482 blue:0.7482 alpha:1.0].CGColor;
        self.layer.borderWidth = 0.5f;
    }
    
    return self;
}

- (void)createSelectSortButton{
    
    self.allButton      = [LeftRightButton buttonWithType:UIButtonTypeCustom];
    self.nearbyButton   = [LeftRightButton buttonWithType:UIButtonTypeCustom];
    self.autoSortButton = [LeftRightButton buttonWithType:UIButtonTypeCustom];
    self.filterButton   = [LeftRightButton buttonWithType:UIButtonTypeCustom];

    _arrButton          = @[_allButton, _nearbyButton, _autoSortButton, _filterButton];
    NSArray *arrTitiles = @[@"全部", @"附近", @"智能排序", @"筛选"];
    
    for (NSInteger i = 0; i < _arrButton.count; i++) {
    
        UIButton *button = [_arrButton objectAtIndex:i];
        [button setTitle:[arrTitiles objectAtIndex:i] forState:UIControlStateNormal];
        
        [button addTarget:self action:@selector(allButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        
        [button setTag:10000 + i];
        
        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
        [button setTitleColor:[UIColor greenColor] forState:UIControlStateHighlighted];
        
        
        [button setTitleShadowColor:[UIColor greenColor] forState:UIControlStateNormal];
        
        [button addTarget:self action:@selector(allButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        
        [button.layer setBorderColor:[UIColor colorWithRed:0.837 green:0.837 blue:0.837 alpha:1.0].CGColor];
        
        [button.layer setBorderWidth:1.0];
//
//        [button.layer setMasksToBounds:YES];
//        
//        button.showsTouchWhenHighlighted = YES;
        
        [self addSubview:button];
        
        [button setImage:[UIImage imageNamed:@"triangle"] forState:UIControlStateNormal];

        

    }

    
}
- (void)layoutSubviews{
    [super layoutSubviews];
    
    for (NSInteger i = 0; i < 4; i++) {
        LeftRightButton *button = [self viewWithTag:10000 + i];
        button.frame = CGRectMake(i * (Button_Width + Row_Space ), 0, Button_Width, self.frame.size.height);

    }
}
- (void)allButtonAction:(UIButton *)sender{

    
    if (sender == _selectButton) {
        
        
    } else {
        [sender setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
        
        [_selectButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    _selectButton = sender;
    
    NSLog(@"%@ %ld", sender.titleLabel.text, sender.tag);
    
    
    
    
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleDefault;
    //UIStatusBarStyleDefault = 0 黑色文字，浅色背景时使用
    //UIStatusBarStyleLightContent = 1 白色文字，深色背景时使用
}

- (BOOL)prefersStatusBarHidden
{
    return YES; // 返回NO表示要显示，返回YES将hiden
}
@end
