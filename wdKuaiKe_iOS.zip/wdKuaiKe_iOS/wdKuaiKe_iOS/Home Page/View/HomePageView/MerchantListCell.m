//
//  TableViewCell.m
//  WDKKtest
//
//  Created by Skyer God on 16/7/20.
//  Copyright © 2016年 weiDianKuaiKe. All rights reserved.
//
#define Start_X 15.0f
#define Start_Y 10.f
#define Row_Space 15.0f

#define ImageWidth self.frame.size.height - (2 * Start_Y)
#import "MerchantListCell.h"

@interface MerchantListCell ()

@property (nonatomic, retain) NSMutableArray *arrButton;
@property (nonatomic, retain) NSArray *arrTempB;

@end
@implementation MerchantListCell

-(void)setFrame:(CGRect)frame{
    frame.origin.y += 5;
    frame.size.height -= 5;
    [super setFrame:frame];
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self create];
        self.layer.borderWidth = .5f;
        self.layer.borderColor = [UIColor colorWithRed:0.7834 green:0.7834 blue:0.7834 alpha:1.0].CGColor;
    }
    return self;
}
- (void)create{

    //设置商家列表图片
    self.menuImageV = [[UIImageView alloc] init];
    self.menuImageV.backgroundColor = [UIColor blueColor];
    
    self.menuImageV.image = [UIImage imageNamed:@"example"];
    [self.contentView addSubview:_menuImageV];
    
    //设置商家名
    self.titleLabel = [[UILabel alloc] init];
    
    self.titleLabel.text = @"远洋私厨(软件园店)";
    
    self.titleLabel.textAlignment = NSTextAlignmentLeft;
    
    [self.contentView addSubview:_titleLabel];
     //设置商家名字后标签
    
    self.tagLabel = [[UILabel alloc] init];
    
    self.tagLabel.text = @"排";
    
    self.tagLabel.textAlignment = NSTextAlignmentCenter;
    
    self.tagLabel.textColor = [UIColor whiteColor];
    
    self.tagLabel.font = [UIFont systemFontOfSize:16.0];
    
    self.tagLabel.backgroundColor = [UIColor colorWithRed:0.0 green:0.7803 blue:0.0016 alpha:1.0];
    
    [self.contentView addSubview:_tagLabel];
    //设置上架受欢迎程度button， 默认为NO
    for (NSInteger i = 0; i < 5; i++) {
        UIButton *starButton = [UIButton buttonWithType:UIButtonTypeCustom];
        
//        starButton.backgroundColor = [UIColor cyanColor];
        [starButton setBackgroundImage:[UIImage imageNamed:@"starIcon"] forState:UIControlStateNormal];
        [starButton setImage:[UIImage imageNamed:@"starIcon"] forState:UIControlStateNormal];
        
//        [starButton setImage:[UIImage imageNamed:@"grayStarIcon"] forState:UIControlStateHighlighted];
        
        starButton.userInteractionEnabled = NO;
        
        [starButton addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
        
        starButton.tag = 11000 + i;
        
        [_arrButton addObject:starButton];
        
        [self.contentView addSubview:starButton];
        
        
        
        
    }
    
    _arrTempB = _arrButton;
   
    //设置单价／人
    
    self.priceLabel = [[UILabel alloc] init];
    
    _priceLabel.text = @"¥28/人";
    
    _priceLabel.textAlignment = NSTextAlignmentCenter;
    
    _priceLabel.font = [UIFont systemFontOfSize:12.0];
    
    _priceLabel.textColor = [UIColor colorWithRed:0.3013 green:0.3013 blue:0.3013 alpha:1.0];
    [self.contentView addSubview:_priceLabel];
    //设置分类标签
    
    self.categoryLabel = [[UILabel alloc] init];
    
    _categoryLabel.textColor = [UIColor colorWithRed:0.7183 green:0.7183 blue:0.7183 alpha:1.0];
    
    _categoryLabel.text = @"中餐";
    
    _categoryLabel.textAlignment = NSTextAlignmentLeft;
    
    _categoryLabel.font = _priceLabel.font;
    
    [self.contentView addSubview:_categoryLabel];
    
    
    //设置地理位置距离
    
    self.distanceLabel = [[UILabel alloc] init];
    
    _distanceLabel.text = @"会展中心1.3Km";
    
    _distanceLabel.textColor = _categoryLabel.textColor;
    
    _distanceLabel.font = _categoryLabel.font;
    
    [self.contentView addSubview:_distanceLabel];
    
    
    
}
- (void)buttonAction:(UIButton *)sender{
    
    NSLog(@"star %ld", sender.tag);
}

- (void)layoutSubviews{
    
    [super layoutSubviews];
    self.menuImageV.frame = CGRectMake(Start_X, Start_Y, ImageWidth, ImageWidth);
    
    CGRect rect = [_titleLabel.text boundingRectWithSize:CGSizeMake(10000, _titleLabel.frame.size.height) options:NSStringDrawingUsesLineFragmentOrigin attributes:[NSDictionary dictionaryWithObject:[UIFont systemFontOfSize:18] forKey:NSFontAttributeName] context:nil];
    self.titleLabel.frame = CGRectMake(_menuImageV.frame.origin.x + _menuImageV.frame.size.width + Row_Space, _menuImageV.frame.origin.y, rect.size.width, _menuImageV.frame.size.height / 4);
    self.tagLabel.frame = CGRectMake(_titleLabel.frame.origin.x + _titleLabel.frame.size.width, _titleLabel.frame.origin.y + 3, kWidth(20), kWidth(20));

    for (NSInteger i = 0; i < 5; i++) {

        [self viewWithTag:11000 + i].frame = CGRectMake(_titleLabel.frame.origin.x + i * kWidth(20), _titleLabel.frame.size.height + _titleLabel.frame.origin.y, kWidth(20), kWidth(20));
        
    }
    
    self.priceLabel.frame = CGRectMake(_titleLabel.frame.origin.x + kWidth(20) * 5, [self viewWithTag:11004].frame.origin.y, kWidth(60), [self viewWithTag:11004].frame.size.height);
    
    self.categoryLabel.frame = CGRectMake(_titleLabel.frame.origin.x, _menuImageV.origin.y + _menuImageV.frame.size.height - kHeight(30), kWidth(40), kHeight(30));
    
    
    
    self.distanceLabel.frame = CGRectMake(self.viewForLastBaselineLayout.frame.size.width - kWidth(100), _categoryLabel.frame.origin.y, kWidth(100), _categoryLabel.frame.size.height);


    
    
    
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
