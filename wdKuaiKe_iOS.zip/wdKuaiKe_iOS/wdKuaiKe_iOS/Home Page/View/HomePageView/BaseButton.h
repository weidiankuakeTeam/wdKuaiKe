//
//  BaseButton.h
//  WDKKtest
//
//  Created by Skyer God on 16/7/22.
//  Copyright © 2016年 weiDianKuaiKe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseButton : UIButton
@property (nonatomic , assign) CGFloat Image_Y;//
@property (nonatomic, assign) CGFloat Image_X;//
@property (nonatomic, assign) CGFloat Title_Space;//
@end
