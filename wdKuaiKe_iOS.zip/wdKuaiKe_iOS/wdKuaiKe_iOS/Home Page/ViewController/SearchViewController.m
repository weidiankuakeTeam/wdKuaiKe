//
//  SearchViewController.m
//  wdKuaiKe_iOS
//
//  Created by Skyer God on 16/8/9.
//  Copyright © 2016年 weiDianKuaiKe. All rights reserved.
//

#import "SearchViewController.h"

@interface SearchViewController ()

@end

@implementation SearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];

    [self setUpNavigationBarView];
    
}
- (void)setUpNavigationBarView{
    
    UIView *navigationView = [[UIView alloc] init];
    navigationView.backgroundColor = RGB(253,117,119);
    [self.view addSubview:navigationView];
        navigationView.sd_layout.leftEqualToView(self.view).topEqualToView(self.view).rightEqualToView(self.view).heightIs(kHeight(20 + 44));
    
    //设置左边导航栏button
    UIButton *leftBarButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftBarButton setImage:[UIImage imageNamed:@"left-1"] forState:UIControlStateNormal];
    [leftBarButton addTarget:self action:@selector(backItemAction:) forControlEvents:UIControlEventTouchUpInside];
    [navigationView addSubview:leftBarButton];
    
    leftBarButton.sd_layout.leftSpaceToView(navigationView, kWidth(18)).topSpaceToView(navigationView, 20 + 12).widthIs(kWidth(10)).heightIs(kHeight(15));
    
    //设置右边搜索按钮
    UIButton *searchButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [searchButton setTitle:@"搜索" forState:UIControlStateNormal];
    [searchButton.titleLabel setTextColor:[UIColor whiteColor]];
    [searchButton.titleLabel setFont:[UIFont systemFontOfSize:12.0]];
    
    [navigationView addSubview:searchButton];
    searchButton.sd_layout.topSpaceToView(navigationView, 36).rightSpaceToView(navigationView, 13).bottomSpaceToView(navigationView, 14).widthIs(24);
    
    
    
    

    
}
- (void)backItemAction:(UIBarButtonItem *)sender{
    
    self.navigationController.navigationBar.hidden = YES;
    [self.navigationController.view viewWithTag:3000].hidden = NO;
    
    [self.navigationController popViewControllerAnimated:YES];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
