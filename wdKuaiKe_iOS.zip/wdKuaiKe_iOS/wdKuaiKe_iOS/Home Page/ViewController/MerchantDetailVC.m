//
//  MerchantDetailVC.m
//  wdKuaiKe_iOS
//
//  Created by Skyer God on 16/8/4.
//  Copyright © 2016年 weiDianKuaiKe. All rights reserved.
//

#import "MerchantDetailVC.h"

#import "CarouselHeaderView.h"

#import "MerchantOptionBTCell.h"

#import "PhoneTableViewCell.h"

#import "LocationTableViewCell.h"

#import "EvaluateDetailListCell.h"

@interface MerchantDetailVC ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIView *navigationView;

@property (nonatomic ,strong) UITableView *tableView;

@property (nonatomic, retain) UIScrollView *scrollV;

@property (nonatomic, retain) UILabel *pageLabel;

@property (nonatomic, retain) NSArray *arrImages;
@end

@implementation MerchantDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    
    
    [self initNavigationBar];
    [self setUpTableView];
}
- (void)setUpTableView{
    self.tableView = [[UITableView alloc] initWithFrame:self.view.frame style:UITableViewStyleGrouped];
    self.tableView.backgroundView.backgroundColor = RGB(210, 210, 210);
    self.tableView.delegate = self;
    self.tableView.dataSource =self;
    self.tableView.separatorStyle = 0;
    self.tableView.backgroundColor = RGB(210,210,210);
    
    [self.view addSubview:_tableView];
    self.tableView.sd_layout.leftSpaceToView(self.view, 0).topSpaceToView(self.view, 0).rightEqualToView(self.view).bottomSpaceToView(self.view, -40);
    
    
#pragma mark -- 注册自定义cell
    
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"tableCell"];
    
    [self.tableView registerClass:[MerchantOptionBTCell class] forCellReuseIdentifier:@"optionButtonCell"];
    [self.tableView registerClass:[PhoneTableViewCell class] forCellReuseIdentifier:@"phoneCell"];
    [self.tableView registerClass:[LocationTableViewCell class] forCellReuseIdentifier:@"locationCell"];
    
    [self.tableView registerClass:[EvaluateDetailListCell class] forCellReuseIdentifier:@"evaluateCell"];
    
}
//tableVIew Delegate

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    if (section == 0) {
    return [self firstHeaderView];
    }
    
    return [self secondHearderView];
    
}
// scrollview滑动时，pageLabel的页面值跟着变化
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    if (scrollView == _scrollV) {
        _pageLabel.text = [NSString stringWithFormat:@"%.0f／%ld", scrollView.contentOffset.x / scrollView.frame.size.width + 1, _arrImages.count];
    }
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return kHeight(175);
    }
    return kHeight(33);
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return 3;
    }
    return 11;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == 0) {
      
        if (indexPath.row == 0) {
          return kHeight(114);
           }
        if (indexPath.row == 1) {
            return kHeight(40 + 14);
        }
            return kHeight(40 + 1);
    }
    return kHeight(100 + 1);

}
#pragma mark -- tableViewCell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == 0) {
    
    if (indexPath.row == 0) {
        MerchantOptionBTCell *merChantCell = [tableView dequeueReusableCellWithIdentifier:@"optionButtonCell" forIndexPath:indexPath];
        
        merChantCell.backgroundColor = [UIColor whiteColor];
        
        merChantCell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        return merChantCell;
        
    }
    if (indexPath.row == 1) {
        PhoneTableViewCell *phoneCell = [tableView dequeueReusableCellWithIdentifier:@"phoneCell" forIndexPath:indexPath];
        phoneCell.selectionStyle = UITableViewCellSelectionStyleNone;
        return phoneCell;
    }
        
    LocationTableViewCell *locationCell = [tableView dequeueReusableCellWithIdentifier:@"locationCell" forIndexPath:indexPath];
    locationCell.selectionStyle = UITableViewCellSelectionStyleNone;
        
    return locationCell;
        
    }  else {
        
        EvaluateDetailListCell *evaluateCell = [tableView dequeueReusableCellWithIdentifier:@"evaluateCell" forIndexPath:indexPath];
        evaluateCell.selectionStyle = UITableViewCellSelectionStyleNone;
        return evaluateCell;
        
    }
}
//设置
- (void)initNavigationBar{
    self.navigationController.navigationBar.hidden = NO;
    
    UIBarButtonItem *backButton = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"形状-1"]style:UIBarButtonItemStylePlain target:self action:@selector(backItemAction:)];
    
    _titleLabel = [[UILabel alloc] init];
    _titleLabel.text = @"商家详情" ;
    _titleLabel.frame = CGRectMake(kWidth(35), kHeight(11 + 22), kWidth(60), kHeight(15));
    _titleLabel.font = [UIFont systemFontOfSize:15.0];
    _titleLabel.textColor = RGB(96,96,96);
    [self.navigationController.view addSubview:_titleLabel];
    
    self.navigationItem.leftBarButtonItem = backButton;
    
    self.navigationController.navigationBar.tintColor = RGB(83,83,83);
    self.navigationController.navigationBar.backgroundColor = [UIColor whiteColor];
    
    //监听是否点击首页tabbarItem  如果点击，响应动作和leftBarButtonItem响应一样
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(backItemAction:) name:@"homePageClick" object:nil];
    
    [self setUpNavigationBarView];
}

#pragma mark -- //rightBarItem点击响应
- (void)backItemAction:(UIBarButtonItem *)sender{
    
    self.titleLabel.hidden = YES;
    self.navigationView.hidden = YES;
    
    self.navigationController.navigationBar.hidden = YES;
    
    [self.navigationController popViewControllerAnimated:YES];
    
    [self.navigationController.view viewWithTag:3000].hidden = NO;
    

    
}
#pragma mark   --  //设置后面三个button 收藏  分享  举报
- (void)setUpNavigationBarView{

    self.navigationView = [[UIView alloc] init];
    
    [self.navigationController.view addSubview:_navigationView];
    
    _navigationView.sd_layout.topEqualToView(_titleLabel).leftSpaceToView(_titleLabel, 0).bottomEqualToView(_titleLabel).widthIs(self.view.bounds.size.width - _titleLabel.frame.origin.x - _titleLabel.frame.size.width);
    //收藏
    UIButton *collectBT = [UIButton buttonWithType:UIButtonTypeCustom];
    [collectBT setImage:[UIImage imageNamed:@"收藏"] forState:UIControlStateNormal];
    [self.navigationView addSubview:collectBT];
    collectBT.sd_layout.topEqualToView(_navigationView).leftSpaceToView(_navigationView, kWidth(210)).heightIs(kHeight(20)).widthIs(kHeight(20));
     //分享
    UIButton *shareBT = [UIButton buttonWithType:UIButtonTypeCustom];
    [shareBT setImage:[UIImage imageNamed:@"分享"] forState:UIControlStateNormal];
    [self.navigationView addSubview:shareBT];
    shareBT.sd_layout.leftSpaceToView(collectBT, kWidth(15)).topEqualToView(_navigationView).widthEqualToHeight(collectBT).heightIs(collectBT.frame.size.height);
    
    //举报
    UIButton *informBT = [UIButton buttonWithType:UIButtonTypeCustom];
    [informBT setImage:[UIImage imageNamed:@"感叹号-(2)"] forState:UIControlStateNormal];
    [self.navigationView addSubview:informBT];
    
    informBT.sd_layout.leftSpaceToView(shareBT, kWidth(15)).topEqualToView(_navigationView).widthEqualToHeight(shareBT).heightIs(shareBT.frame.size.height);
    
    
    
}

#pragma mark --  // 创建tableView的第一个头视图
- (UIView *)firstHeaderView{
    
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, kHeight(175))];
    backView.userInteractionEnabled = YES;
    _arrImages = @[@"first", @"second", @"turnPlay"];
    
    
    _scrollV = [[UIScrollView alloc] initWithFrame:backView.frame];
    _scrollV.contentSize = CGSizeMake(backView.frame.size.width * _arrImages.count, backView.frame.size.height);
    _scrollV.contentOffset = CGPointMake(0, 0);
    
    _scrollV.pagingEnabled = YES;
    _scrollV.bounces = NO;
    
    _scrollV.delegate = self;
    
    for (NSInteger i = 0 ; i < _arrImages.count; i++) {
        
        UIScrollView *scrollZoom = [[UIScrollView alloc] initWithFrame:CGRectMake(self.view.frame.size.width * i, 0, self.view.frame.size.width, self.view.frame.size.height)];
        
        scrollZoom.minimumZoomScale = 1.0;
        scrollZoom.maximumZoomScale = 3.0;
        
        [_scrollV addSubview:scrollZoom];
        
        
        UIImageView *imageV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, backView.frame.size.width, backView.frame.size.height)];
        
        imageV.image = [UIImage imageNamed:[_arrImages objectAtIndex:i]];
        
        [scrollZoom addSubview:imageV];
        
        
    }
    
    [backView addSubview:_scrollV];
    
    
    UIView *blackView = [[UIView alloc] init];
    blackView.backgroundColor = RGBA(0, 0, 0, 0.4);
    [backView addSubview:blackView];
    
    blackView.sd_layout.bottomSpaceToView(backView, 0).leftEqualToView(backView).widthIs(backView.frame.size.width).heightIs(kHeight(32));
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = @"远洋私厨";
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.font = [UIFont systemFontOfSize:15.0];
    
    [blackView addSubview:titleLabel];
    
    titleLabel.sd_layout.leftSpaceToView(blackView, kWidth(17)).topEqualToView(blackView).widthIs(kWidth(60)).bottomEqualToView(blackView);
    
    _pageLabel = [[UILabel alloc] initWithFrame:CGRectMake(kWidth(344), 0, kWidth(40), blackView.frame.size.height)];
    
    _pageLabel.textColor = titleLabel.textColor;
    
    _pageLabel.font = titleLabel.font;
    
    _pageLabel.text = [NSString stringWithFormat:@"%.0f／%ld", _scrollV.contentOffset.x / _scrollV.frame.size.width + 1, _arrImages.count];
    
    [blackView addSubview:_pageLabel];
    
    return backView;
    
    
    
    

}

#pragma mark - 创建tableView第二个头视图
- (UIView *)secondHearderView{
    UIView *secondHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, kHeight(33))];
    secondHeaderView.backgroundColor = [UIColor whiteColor];\
    
    UIButton *titleBT = [UIButton buttonWithType:UIButtonTypeCustom];
    [titleBT setImage:[UIImage imageNamed:@"评论"] forState:UIControlStateNormal];
    [titleBT setTitle:@"餐厅评价" forState:UIControlStateNormal];
    [titleBT setTitleColor:RGB(48, 48, 48) forState:UIControlStateNormal];
    [titleBT.titleLabel setFont:[UIFont systemFontOfSize:12.0]];
    
    [secondHeaderView addSubview:titleBT];
    titleBT.sd_layout.leftSpaceToView(secondHeaderView, kWidth(24)).topSpaceToView(secondHeaderView, kHeight(11)).widthIs(kWidth(75)).bottomSpaceToView(secondHeaderView, kHeight(7));
    [titleBT setTitleEdgeInsets:UIEdgeInsetsMake(0, kWidth(10), 0, 0)];
    
    UIButton *arrowBT = [UIButton buttonWithType:UIButtonTypeCustom];
    [arrowBT setImage:[UIImage imageNamed:@"形状-1-拷贝"] forState:UIControlStateNormal];
    
    [secondHeaderView addSubview:arrowBT];
    arrowBT.sd_layout.topSpaceToView(secondHeaderView, kHeight(12)).bottomSpaceToView(secondHeaderView, kHeight(11)).rightSpaceToView(secondHeaderView, kWidth(15)).widthIs(kWidth(8));
    
    
    
    return secondHeaderView;
}
- (void)rightButtonAction:(UINavigationItem *)sender{
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
