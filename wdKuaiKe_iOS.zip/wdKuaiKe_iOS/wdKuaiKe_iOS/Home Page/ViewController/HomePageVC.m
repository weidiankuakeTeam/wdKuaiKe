//
//  HomePageVC.m
//  wdKuaiKe_iOS
//
//  Created by Skyer God on 16/8/4.
//  Copyright © 2016年 weiDianKuaiKe. All rights reserved.
//

#import "HomePageVC.h"

#import "RecommendTableViewCell.h"
#import "SelectSortButtonView.h"
#import "MerchantListCell.h"
#import "HeaderView.h"
#import "SerachView.h"
#import "ScanViewController.h"
#import "MerchantDetailVC.h"

#import "SearchViewController.h"

@interface HomePageVC ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UIView *naviView;
@property (nonatomic, strong) UIButton *localtionBT;

@property (nonatomic, strong) UITableView *homeTableView;
@end

@implementation HomePageVC


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self setupSearchBarView];
    //初始化tableView
    [self initWithHomePageTableView];
    
    UIBarButtonItem *backButton = [[UIBarButtonItem alloc] initWithTitle:@"商家详情"  style:UIBarButtonItemStylePlain  target:self  action:nil];
    self.navigationItem.backBarButtonItem = backButton;
    
    
    if ([self respondsToSelector:@selector(setNeedsStatusBarAppearanceUpdate)]) {
        
        [self prefersStatusBarHidden];
        
        [self performSelector:@selector(setNeedsStatusBarAppearanceUpdate)];
        
    }
    
    
}
- (BOOL)prefersStatusBarHidden
{
    return YES;
}
#pragma mark -- //创建searchbar
- (void)setupSearchBarView{
    
    self.navigationController.navigationBar.hidden = YES;
    //搜索栏视图
    self.naviView = [[UIView alloc] init];
    self.naviView.tag = 3000;
    [self.navigationController.view addSubview:self.naviView];
    self.naviView.frame = CGRectMake(kWidth(10), kHeight(20), self.view.bounds.size.width - kWidth(10) * 2, kHeight(30));
#pragma mark  --  //定位按钮
    _localtionBT = [UIButton buttonWithType:UIButtonTypeCustom];
    _localtionBT.frame = CGRectMake(0, 0, kWidth(70), self.naviView.frame.size.height);
    [_localtionBT setTitle:@"厦门" forState:UIControlStateNormal];
    _localtionBT.titleLabel.textAlignment = NSTextAlignmentLeft;
    [_localtionBT setImage:[UIImage imageNamed:@"icon_searchBar_arrow@2x"] forState:UIControlStateNormal];
    [_localtionBT setImage:[UIImage imageNamed:@"icon_searchBar_arrow@2x"] forState:UIControlStateSelected];
    [_localtionBT setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, kWidth(20))];
    [_localtionBT setImageEdgeInsets:UIEdgeInsetsMake(0, _localtionBT.frame.size.width - kWidth(20 ), 0, 0)];
    [_localtionBT addTarget:self action:@selector(starSearchLocation:) forControlEvents:UIControlEventTouchUpInside];
    [self.naviView addSubview:_localtionBT];
    
    
#pragma mark  --  //创建搜索框
    UIButton *searchBarView = [UIButton buttonWithType:UIButtonTypeCustom];
    searchBarView.frame = CGRectMake(_localtionBT.frame.size.width + kWidth(5), _localtionBT.frame.origin.y, self.naviView.frame.size.width - _localtionBT.frame.size.width * 2, self.naviView.frame.size.height);

    [searchBarView setImage:[UIImage imageNamed:@"icon_search"] forState:UIControlStateNormal];
    searchBarView.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, kWidth(40));
    
    [searchBarView setTitle:@"请输入商家或者商家名称" forState:UIControlStateNormal];
    [searchBarView addTarget:self action:@selector(seachBarAction:) forControlEvents:UIControlEventTouchUpInside];
    
    searchBarView.titleEdgeInsets = UIEdgeInsetsMake(0, -kWidth(20), 0, 0);
    searchBarView.titleLabel.textColor = [UIColor colorWithRed:0.1651 green:0.1651 blue:0.1651 alpha:1.0];
    searchBarView.titleLabel.font = [UIFont systemFontOfSize:15];
    searchBarView.layer.borderWidth = 1.0f;
    searchBarView.layer.borderColor = [UIColor whiteColor].CGColor;
    searchBarView.layer.cornerRadius = searchBarView.frame.size.height / 6;
    [self.naviView addSubview:searchBarView];
    
#pragma mark --    //创建扫描按钮
    UIButton *scanButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [scanButton setBackgroundImage:[UIImage imageNamed:@"icon_scan"] forState:UIControlStateNormal];
    [scanButton addTarget:self action:@selector(scanButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.naviView addSubview:scanButton];
    
    
    
    scanButton.sd_layout.leftSpaceToView(searchBarView, kWidth(25)).topSpaceToView(searchBarView, - self.naviView.frame.size.height + kWidth(3)).widthIs(self.naviView.frame.size.height - kWidth(3) * 2).heightEqualToWidth();
    
    
    
    
}

- (void)seachBarAction:(UIButton *)sender{
    

    self.naviView.hidden = YES;
    
    SearchViewController *searchVC  = [[SearchViewController alloc] init];
    
    [self.navigationController pushViewController:searchVC animated:YES];
    
}
- (void)starSearchLocation:(UIButton *)sender{
    
    
}
//点击扫描
-(void)scanButtonClick:(UIButton *)sender{
    
    ScanViewController *scanVC = [[ScanViewController alloc] init];
    
    
    [self.navigationController pushViewController:scanVC animated:YES];
    
}
#pragma mark -- //初始化首页tableView
- (void)initWithHomePageTableView{
    _homeTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];
    _homeTableView.backgroundColor = [UIColor colorWithRed:0.9627 green:0.9627 blue:0.9627 alpha:1.0];
    _homeTableView.dataSource = self;
    _homeTableView.delegate = self;
    
    //    homeTableView.separatorStyle = 0;
    
    [_homeTableView registerClass:[UITableViewHeaderFooterView class] forHeaderFooterViewReuseIdentifier:@"headerView"];
    [_homeTableView registerClass:[RecommendTableViewCell class] forCellReuseIdentifier:@"recommendImageViewCell"];
    [_homeTableView registerClass:[MerchantListCell class] forCellReuseIdentifier:@"homeTableViewCell"];
    

    
    //    设置当you导航栏自动添加64的高度的属性为NO
    self.automaticallyAdjustsScrollViewInsets = NO;

    [self.view addSubview:_homeTableView];
    
    self.homeTableView.sd_layout.leftSpaceToView(self.view, 0).topSpaceToView(self.view, 0).rightEqualToView(self.view).bottomSpaceToView(self.view, 49);
    
}
//tableView协议方法
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 460;
    } else {
        return 40;
    }
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if (section == 0) {

        //建立首页展示头视图
        HeaderView *headerView = [[HeaderView alloc] init];
    
        headerView.backgroundColor = [UIColor whiteColor];
        
        return headerView;
        
    } else {
        
        SelectSortButtonView *sortView = [[SelectSortButtonView alloc] init];
        sortView.backgroundColor = [UIColor whiteColor];
        return sortView;
    }
    
}
//-(nullable NSArray<UITableViewRowAction *> * )tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    UITableViewRowAction *deleteRoWAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleDefault title:@"删除" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath)
//                                             {//title可自已定义
//                                                 NSLog(@"111");
//                                             }];//此处是iOS8.0以后苹果最新推出的api，UITableViewRowAction，Style是划出的标签颜色等状态的定义，这里也可自行定义
//    UITableViewRowAction *editRowAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleDefault title:@"置顶" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
//        NSLog(@"222");
//    }];
//    editRowAction.backgroundColor = [UIColor colorWithRed:0 green:124/255.0 blue:223/255.0 alpha:1];//可以定义RowAction的颜色
//    return @[deleteRoWAction, editRowAction];//最后返回这俩个RowAction 的数组
//}

//设置点击商家列表响应
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    MerchantDetailVC *merchantVC = [[MerchantDetailVC alloc] init];
    
    self.naviView.hidden = YES;
    
    [self.navigationController pushViewController:merchantVC animated:YES];
    
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return 0;
    }
    return 10;
}
//设置cell高度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    if (indexPath.row == 0) {
        return  kHeight(150);
    } else return kHeight(120);
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    //设置两个图片
    if (indexPath.row == 0) {
        
        RecommendTableViewCell *recommendImageViewCell = [[RecommendTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"recommendImageViewCell"];
        
        recommendImageViewCell.selectionStyle          = UITableViewCellSelectionStyleNone;
        
        
        return recommendImageViewCell;
    }
    
    //设置四个列表排序button
    
    MerchantListCell *cell                         = [[MerchantListCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"homeTableViewCell"];
    
    cell.selectionStyle                            = UITableViewCellSelectionStyleNone;
    
    return cell;
    
    
}
//
- (void)buttonAction:(UIButton *)sender{
    
    NSLog(@"微点筷客%ld", sender.tag);
    
}


-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    

    
    CGFloat alphaValue = scrollView.contentOffset.y / 120;
    if (alphaValue < 120) {
        _naviView.alpha = 1 - alphaValue;
    } else {
        _naviView.hidden = YES;
    }

    

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
