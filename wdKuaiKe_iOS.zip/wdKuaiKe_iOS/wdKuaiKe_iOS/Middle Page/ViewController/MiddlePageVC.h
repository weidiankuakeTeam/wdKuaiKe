//
//  MiddlePageVC.h
//  wdKuaiKe_iOS
//
//  Created by Skyer God on 16/8/4.
//  Copyright © 2016年 weiDianKuaiKe. All rights reserved.
//

#import "ViewController.h"

@interface MiddlePageVC : ViewController

@end
